export const HOME_DATA = "HOME_DATA";

//MAIN_CATEGORY page
export const MAIN_CATEGORY = "MAIN_CATEGORY";

//location
export const LOCATION = "LOCATION";

//user data
export const USERDATA = "USERDATA";
export const USERADDRESS = "USERADDRESS";

//CART
export const ADD_TO_CART = 'ADD_TO_CART'
export const REMOVE_FROM_CART = 'REMOVE_FROM_CART'
export const CLEAR_CART = 'CLEAR_CART'

export const INCREMENT_QTY = 'INCREMENT_QTY'
export const DECREMENT_QTY = 'DECREMENT_QTY'